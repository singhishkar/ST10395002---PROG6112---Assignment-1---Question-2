/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package carpartsstore;
/*References:
https://stackoverflow.com/
Textbook: Java Programming By Joyce Farrell - Ninth Edition
*/
import java.util.Scanner;

public class CarPartsStore {
    Scanner kb = new Scanner(System.in);

    public static void main(String[] args) {
        CarPartsStore cps = new CarPartsStore();

        System.out.println("*****GOLDWAGEN PARTSFINDER*****");
        System.out.println("-------------------------------");
        cps.mainMenu(); //Start the main menu of the Car Parts Store
    }

    //The main menu of the application
    public void mainMenu() {
        Account acc = new Account(this); //Create an Account instance and pass the CarPartsStore instance to it
        boolean menuMain = false;

        //Allows the user to register or login and takes them to the Account class
        while (!menuMain) {
            System.out.println("Please select an option:\n"
                + "1. Register \n"
                + "2. Login");
            int choiceOne = kb.nextInt();

            switch (choiceOne) {
                case 1:
                    acc.RegisterUsername(); //Call the registration method from the Account class
                    menuMain = true; //Exit the main menu loop
                    break;
                case 2:
                    acc.Login(); //Call the login method from the Account class
                    menuMain = true; //Exit the main menu loop
                    break;
                default:
                    System.out.println("Incorrect input. Please enter a valid option!!");
                    break;
            }
        }
    }

    //Menu for managing parts
    public void menuOne() {
        boolean menuOne = false;
        Product product = new Product(this);

        while (!menuOne) {
            System.out.println("Please select an option:\n"
                    + "1. Add a part\n"
                    + "2. Search for a part\n"
                    + "3. Display all parts\n"
                    + "4. Exit");
            int choiceTwo = kb.nextInt();

            switch (choiceTwo) {
                case 1:
                    addParts(); //Call the method to add parts
                    menuOne = true;
                    break;
                case 2:
                    product.searchPart(); //Call the method to search for parts from the Product class
                    menuOne = true;
                    break;
                case 3:
                    product.displayParts(); //Call the method to display all parts from the Product class
                    menuOne = true;
                    break;
                case 4:
                    exit(); //Exit the application
                    menuOne = true; // Exit the menu loop
                    break;
                default:
                    System.out.println("Incorrect input!! Please enter a valid option.");
                    break;
            }
        }
    }

    //Method for adding parts to the store
    public void addParts() {
        boolean menuParts = false;
        Suspension suspension = new Suspension(this);
        Lubricants lubricants = new Lubricants(this);
        Filters filters = new Filters(this);
        Engine engine = new Engine(this);
        DriveTrain drive = new DriveTrain(this);

        while (!menuParts) {
            System.out.println("Please select the department you are adding to:\n"
                    + "1. Suspension Components\n"
                    + "2. Lubricants\n"
                    + "3. Filters\n"
                    + "4. Engine Components\n"
                    + "5. DriveTrain Components");
            int prdctChoice = kb.nextInt();

            switch (prdctChoice) {
                case 1:
                    suspension.suspensionMenu(); //Call the suspension menu from the Suspension class
                    menuParts = true; //Exit the menu loop
                    break;
                case 2:
                    lubricants.lubricantsMenu(); //Call the lubricants menu from the Lubricants class
                    menuParts = true; //Exit the menu loop
                    break;
                case 3:
                    filters.filtersMenu(); //Call the filters menu from the Filters class
                    menuParts = true; //Exit the menu loop
                    break;
                case 4:
                    engine.engineMenu(); //Call the engine menu from the Engine class
                    menuParts = true; //Exit the menu loop
                    break;
                case 5:
                    drive.drivetrainMenu(); //Call the drivetrain menu from the DriveTrain class
                    menuParts = true; //Exit the menu loop
                    break;
                default:
                    System.out.println("Incorrect input!! Please enter a valid option.");
                    break;
            }
        }
    }

    //Method to exit the application
    public void exit() {
        System.out.println("---------------------------------------------------");
        System.out.println("*****THANK YOU FOR USING GOLDWAGEN PARTSFINDER******");
        System.exit(0); //Exit the application
    }
}
