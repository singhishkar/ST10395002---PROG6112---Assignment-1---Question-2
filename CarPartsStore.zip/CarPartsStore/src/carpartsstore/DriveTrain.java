/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package carpartsstore;

import java.util.Scanner;

//The DriveTrain class represents a category of products related to a car's drivetrain
//It extends the Product class and provides methods to select and manage clutch kits and flywheels
    public class DriveTrain extends Product {
       Scanner kb = new Scanner(System.in);

    //Constructor for the DriveTrain class
    //It initializes the class with a reference to the CarPartsStore (cps)
    public DriveTrain(CarPartsStore cps) {
        super(cps);
    }

    //Method to select and add clutch kit brands to the list of selected brands
    public void clutchKits() {
            String[] clutchBrands = {"Blue Print", "LuK", "ZF SACHS", "Schaeffler Group"};
            boolean correctCK = false;

            while (!correctCK) {
                System.out.println("Please select clutch kit brand:");
                System.out.println("1. Blue Print\t2. LuK\t3. ZF SACHS\t4. Schaeffler Group");
                int brandSA = kb.nextInt();

                switch (brandSA) {
                    case 1:
                        brand.add(clutchBrands[0]);
                        correctCK = true;
                        break;
                    case 2:
                        brand.add(clutchBrands[1]);
                        correctCK = true;
                        break;
                    case 3:
                        brand.add(clutchBrands[2]);
                        correctCK = true;
                        break;
                    case 4:
                        brand.add(clutchBrands[3]);
                        correctCK = true;
                        break;
                    default:
                        System.out.println("Incorrect input. Please enter a valid option!!");
                        break;
                }
            }
            super.generalPart();    //Calls in superclass
            cps.menuOne();  //Takes user back to menu
     }

    //Method to select and add flywheel brands to the list of selected brands
    public void flywheels() {
        String [] flywheelBrands = {"LuK", "ZF SACHS", "Schaeffler Group"};
        boolean correctFly = false;
        
        while (!correctFly) {
        System.out.println("Please select flywheel brand:");
        System.out.println("1.LuK\t2.ZF SACHS\t3.Schaeffler Group");
        int brandSA = kb.nextInt();
        
        switch (brandSA) {
                case 1:
                    brand.add(flywheelBrands[0]); correctFly = true; break;
                case 2:
                    brand.add(flywheelBrands[1]); correctFly = true; break;
                case 3:
                    brand.add(flywheelBrands[2]); correctFly = true; break;
                default:
                    System.out.println("Incorrect input. Please enter a valid option!!"); break;
            }
        }
        super.generalPart();    //Calls in superclass
        cps.menuOne();  //Takes user back to menu
    }
    
    //Method to display a menu for selecting the category of drivetrain products (clutch kits or flywheels)
    public void drivetrainMenu() {
        boolean driveBoolean = false;
        
        while(!driveBoolean) {
        System.out.println("Please select a category:\n"
                + "1.Clutch Kits\n"
                + "2.Flywheels");
        int driveChoice = kb.nextInt();
        
        switch(driveChoice) {
                case 1:
                    clutchKits(); driveBoolean = true; break;
                case 2:
                    flywheels(); driveBoolean = true; break;
                default:
                    System.out.println("Incorrect input. Please enter a valid option!!");; break;
            }
          }
        }
    }
