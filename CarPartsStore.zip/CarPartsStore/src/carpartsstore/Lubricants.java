/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package carpartsstore;

import java.util.Scanner;
import carpartsstore.Product;
import java.util.ArrayList;

//The Lubricants class represents a category of products related to a car's lubricants (liquids)
//It extends the Product class and provides methods to select and manage engine oil, transmission oil and antifreeze
    public class Lubricants extends Product {
        Scanner kb = new Scanner(System.in);

    //Constructor for the Engine class
    //It initializes the class with a reference to the CarPartsStore (cps)
    public Lubricants(CarPartsStore cps) {
        super(cps);
    }

    //Method to select and add engine oil brands to the list of selected brands
    public void engineOil() {
        String [] engineOilBrands = {"Castrol Limited", "Liqui Moly GmbH", "Mobil1", "Pennzoil", "Shell plc", "Wolf Corporation"};
        boolean correctEO = false;
        
        while (!correctEO) {
        System.out.println("Please select engine oil brand:");
        System.out.println("1.Castrol Limited\t2.Liqui Moly GmbH\t3.Mobil1\t4.Pennzoil\t5.Shell plc\t6.Wolf Corporation");
        int brandSA = kb.nextInt();
        
        switch (brandSA) {
                case 1:
                    brand.add(engineOilBrands[0]); correctEO = true; break;
                case 2:
                    brand.add(engineOilBrands[1]); correctEO = true; break;
                case 3:
                    brand.add(engineOilBrands[2]); correctEO = true; break;
                case 4:
                    brand.add(engineOilBrands[3]); correctEO = true; break;
                case 5:
                    brand.add(engineOilBrands[4]); correctEO = true; break;
                case 6:
                    brand.add(engineOilBrands[5]); correctEO = true; break;
                default:
                    System.out.println("Incorrect input. Please enter a valid option!!");; break;
            }
        }
        super.generalPart();    //Calls in superclass
        cps.menuOne();  //Takes user back to menu
    }
    
    //Method to select and add transmission oil brands to the list of selected brands
    public void transmissionOil() {
        String [] transmissionOilBrands = {"Castrol Limited", "FEBI-Bilstein Gmbh", "Liqui Moly GmbH", "Shell plc", "Wolf Corporation"};
        boolean correctTrans = false;
        
        while (!correctTrans) {
        System.out.println("Please select transmission oil brand:");
        System.out.println("1.Castrol Limited\t2.FEBI-Bilstein Gmbh\t3.Liqui Moly GmbH\t4.Shell plc\t5.Wolf Corporation");
        int brandSA = kb.nextInt();
        
        switch (brandSA) {
                case 1:
                    brand.add(transmissionOilBrands[0]); correctTrans = true; break;
                case 2:
                    brand.add(transmissionOilBrands[1]); correctTrans = true; break;
                case 3:
                    brand.add(transmissionOilBrands[2]); correctTrans = true; break;
                case 4:
                    brand.add(transmissionOilBrands[3]); correctTrans = true; break;
                case 5:
                    brand.add(transmissionOilBrands[4]); correctTrans = true; break;
                default:
                    System.out.println("Incorrect input. Please enter a valid option!!");; break;
            }
        }
        super.generalPart();    //Calls in superclass
        cps.menuOne();  //Takes user back to menu
    }
    
    //Method to select and add antifreeze brands to the list of selected brands
    public void antiFreeze () {
        String [] antiFreezeBrands = {"Castrol Limited", "Eurol Lubricants", "HEPU® ", "Prestone® ", "Valvoline Inc."};
        boolean correctbrandAF = false;
        
        while (!correctbrandAF) {
        System.out.println("Please select antifreeze brand:");
        System.out.println("1.Castrol Limited\t2.Eurol Lubricants\t3.HEPU® \t4.Prestone® \t5.Valvoline Inc.");
        int brandSA = kb.nextInt(); 
        
        switch (brandSA) {
                case 1:
                    brand.add(antiFreezeBrands[0]); correctbrandAF = true; break;
                case 2:
                    brand.add(antiFreezeBrands[1]); correctbrandAF = true; break;
                case 3:
                    brand.add(antiFreezeBrands[2]); correctbrandAF = true; break;
                case 4:
                    brand.add(antiFreezeBrands[3]); correctbrandAF = true; break;
                case 5:
                    brand.add(antiFreezeBrands[4]); correctbrandAF = true; break;
                default:
                    System.out.println("Incorrect input. Please enter a valid option!!");; break;
            }
        }
        super.generalPart();    //Calls in superclass
        cps.menuOne();  //Takes user back to menu
    }
    
     //Method to display a menu for selecting the category of lubricant products (engine oil, transmission oil or antifreeze)
    public void lubricantsMenu() {
        boolean lubBoolean = false;
        
        while(!lubBoolean) {
        System.out.println("Please select a category:\n"
                + "1.Engine Oil\n"
                + "2.Transmission Oil\n"
                + "3.Antifreeze");
        int lubChoice = kb.nextInt();
        
        switch(lubChoice) {
                case 1:
                    engineOil(); lubBoolean = true; break;
                case 2:
                    transmissionOil(); lubBoolean = true; break;
                case 3:
                    antiFreeze(); lubBoolean = true; break;
                default:
                    System.out.println("Incorrect input. Please enter a valid option!!");; break;
            }
          }
        }
    }
