/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package carpartsstore;

import java.util.ArrayList;
import java.util.Scanner;
/*
Represents a class for managing products in a car parts store.
This class allows the addition, searching, and display of product information.
It is associated with a CarPartsStore instance.
*/

/**
 *
 * @author ishka
 */
public class Product {
    Scanner kb = new Scanner(System.in);
    
    // ArrayLists to store product information
    public static ArrayList<String> brand = new ArrayList<>();
    public static ArrayList<Double> price = new ArrayList<>();
    public static ArrayList<Integer> quantity = new ArrayList<>();
    public static ArrayList<String> manufacturer = new ArrayList<>();
    public static ArrayList<String> model = new ArrayList<>();
    public static ArrayList<String> description = new ArrayList<>();
    public static ArrayList<String> code = new ArrayList<>();
    final CarPartsStore cps;
    
    /* 
    Constructor for the Product class.
    Initializes the class with a reference to a CarPartsStore instance.
       
    @param cps The CarPartsStore instance associated with this product.
     */
    
    public Product(CarPartsStore cps) {
        this.cps = cps;
    }
    /*
    Allows the user to input general product information such as price, quantity, manufacturer, etc.
    Generates a unique product code based on the manufacturer and user input.
    */
    
    public void generalPart() {
        //Input product details
        
        System.out.println("Enter product price:");
        double prdctPrice = kb.nextDouble();
        price.add(prdctPrice);  //Adds price entered to price arrayList

        System.out.println("Enter product quantity:");
        int prdctQuantity = kb.nextInt();
        quantity.add(prdctQuantity);    //Adds quantity entered to quantity arrayList

        System.out.println("Enter vehicle manufacturer:");
        String prdctManufacturer = kb.next();
        manufacturer.add(prdctManufacturer);    //Adds manufacturer entered to manufacturer arrayList

        System.out.println("Enter vehicle model:");
        String manuModel = kb.next();
        model.add(manuModel);   //Adds model entered to model arrayList

        System.out.println("Enter product description:");
        String prdctDesc = kb.next();
        description.add(prdctDesc); //Adds manufacturer entered to manufacturer arrayList

        boolean codeChar = false;
        while (!codeChar) { //While loop shall continue until correct code is entered
            System.out.println("Code must be 8 characters or less.\n"
                + "Enter product code:");
            String prdctCode = kb.next();

            if (prdctCode.length() > 0 && prdctCode.length() <= 8) {
                String codeTwo = prdctManufacturer.substring(0, 2).toUpperCase();   //Creates a unique code to the part using the first 2 letters of the manufacturer enetred to the code
                String codeOne = codeTwo + prdctCode;
                System.out.println("The product code is: " + codeOne);  //Displays to the user the updated code
                code.add(codeOne);
                codeChar = true;
            } else if (prdctCode.length() <= 0) {
                System.out.println("You have not entered a code. Please try again...");
            } else if (prdctCode.length() > 8) {
                System.out.println("Your code is too long. Please try again...");
            }
        }
    }
    
    /*
    Allows the user to search for a product by its code and view its details.
    Provides an option to delete the product.
    */
    public void searchPart() {
        if (code.isEmpty()) {   //Failsafe if user wants to search but no parts are entered
        System.out.println("Database is empty. Please add parts to the inventory first...");
        cps.menuOne();
        }
        
        // Search for a product by code
        System.out.println("Please enter the part code:");
        String searchQuery = kb.next();

        boolean found = false; 
        boolean cancel = false;
        boolean correctOption = false;

        for (int i = 0; i < code.size(); i++) {
            if (code.get(i).equals(searchQuery)) {
                while(!correctOption) {
                    System.out.println("\nPART " + (i+1) + "\n"
                    + "----------------------------------------\n"
                    + "Brand: " + brand.get(i) + "\n"
                    + "Price R: " + price.get(i) + "\n" 
                    + "Quantityof product : " + quantity.get(i) + "\n"
                    + "Manufacturer: " + manufacturer.get(i) + "\n"
                    + "Model: " + model.get(i) + "\n"
                    + "Description: " + description.get(i) + "\n"
                    + "Part Code: " + code.get(i)
                    + "----------------------------------------\n");
                
                    // Display product details and provide delete option
                    
                System.out.println("Do you wish to delete part " + code.get(i) + " and all its associated information from the system? Yes (y) to delete or No (n) to cancel.");
                String deleteConfirmation = kb.next();
                switch (deleteConfirmation.toLowerCase()) {
                    case "y" ->
                    {
                        //Removes all associated details with that part code
                        brand.remove(i);
                        price.remove(i);
                        manufacturer.remove(i);
                        model.remove(i);
                        description.remove(i);
                        code.remove(i);
                        found = true; // Set the flag to true
                        correctOption = true;
                        break;
                    }
                    case "n" ->
                    {
                        cancel = true;
                        correctOption = true;
                        cps.menuOne();
                        break;
                    }
                    default -> System.out.println("Please enter only one of the following options: \"y\" or \"n\": ");
                }
             }
          }
       }
        
        if (found) {
            System.out.println("The part details have been deleted successfully.");
        } else if (cancel) {
            System.out.println("Deletion aborted...");  //If 'n' (No) is selected
        }
        else {
            System.out.println("Part code: " + searchQuery + " not found.");    //If part searched is not found
        }
        
        cps.menuOne();  //Takes them back to the menu
    }
    
    //Displays the details of all products in the inventory
    public void displayParts() {
        if (code.isEmpty()) {   //Failsafe if user wants to search but no parts are entered
        System.out.println("Database is empty. Please add parts to the inventory first...");
        cps.menuOne();
        }
        
        //Display details of all products in the inventory
        for (int i = 0; i < code.size(); i++)
        {
            System.out.println("\nPART " + (i+1) + "\n"
                    + "----------------------------------------\n"
                    + "Brand: " + brand.get(i) + "\n"
                    + "Price R: " + price.get(i) + "\n" 
                    + "Quantity of product : " + quantity.get(i) + "\n"
                    + "Manufacturer: " + manufacturer.get(i) + "\n"
                    + "Model: " + model.get(i) + "\n"
                    + "Description: " + description.get(i) + "\n"
                    + "Part Code: " + code.get(i)
                    + "----------------------------------------\n");
        }
        cps.menuOne();  //Takes them back to the menu
    }
    
}

