/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package carpartsstore;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class AccountTest {
    private Account account;
    
    @Before
    public void setUp() {
        //Create an instance of the CarPartsStore class for testing purposes
        CarPartsStore cps = new CarPartsStore();
        account = new Account(cps);
    }

    @Test
    public void testRegisterUsername() {
        //Create an input stream with mock user input for testing
        String simulatedInput = "john_doe\n";
        InputStream inputStream = new ByteArrayInputStream(simulatedInput.getBytes());
        System.setIn(inputStream);

        //Create an output stream to capture printed output
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outputStream));

        //Call the RegisterUsername method
        account.RegisterUsername();

        //Reset System.in and System.out to their original values
        System.setIn(System.in);
        System.setOut(System.out);

        //Verify that the correct username has been added to the ArrayList
        ArrayList<String> usernames = account.getUsernames();
        assertTrue(usernames.contains("john_doe"));
    }
    
    @Test
    public void testRegisterPassword() {
        //Create an input stream with mock user input for testing
        String simulatedInput = "TestPass123\n";
        InputStream inputStream = new ByteArrayInputStream(simulatedInput.getBytes());
        System.setIn(inputStream);

        //Create an output stream to capture printed output
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outputStream));

        //Call the RegisterPassword method
        account.RegisterPassword();

        //Reset System.in and System.out to their original values
        System.setIn(System.in);
        System.setOut(System.out);

        //Get the console output and convert it to a string
        String consoleOutput = outputStream.toString().trim();

        //Assert that the correct password message is displayed in the console output
        assertTrue(consoleOutput.contains("Password captured successfully."));
        assertTrue(consoleOutput.contains("Password is: TestPass123"));
        assertTrue(consoleOutput.contains("Account created successfully."));
    }
    
    @Test
    public void testLogin() {
        //Create an instance of CarPartsStore and Account
        CarPartsStore cps = new CarPartsStore();
        Account account = new Account(cps);

        //Register a test account
        account.RegisterUsername();
        account.RegisterPassword();

        //Create an input stream with mock user input for testing
        String simulatedInput = "john_doe\nTestPass123\n"; // Include newline characters to simulate user pressing Enter
        InputStream inputStream = new ByteArrayInputStream(simulatedInput.getBytes());
        System.setIn(inputStream);

        //Create an output stream to capture printed output
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outputStream));

        //Call the Login method
        account.Login();

        //Reset System.in and System.out to their original values
        System.setIn(System.in);
        System.setOut(System.out);

        //Check if the expected output contains the welcome message
        String expectedOutput = "Welcome John Doe, it is great to see you again!";
        assertTrue(outputStream.toString().contains(expectedOutput));
    }
}
