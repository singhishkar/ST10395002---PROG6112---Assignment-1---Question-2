/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package carpartsstore;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.Scanner;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class ProductTest {
    
    private Product product;
    private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
    private final ByteArrayOutputStream errContent = new ByteArrayOutputStream();
    
    @Before
    public void setUp() {
        CarPartsStore cps = new CarPartsStore();
        product = new Product(cps);
        
        System.setOut(new PrintStream(outContent));
        System.setErr(new PrintStream(errContent));
    }
    
    @Test
    public void testGeneralPart() {
        product.kb = new Scanner("10.99\n5\nToyota\nCamry\nTestDescription\n12345678\n");
        
        product.generalPart();
        
        //Verify the expected results
        assertEquals(1, Product.price.size()); //Check if a product was added
        assertEquals(10.99, Product.price.get(0), 0.01); //Check the price
        assertEquals(5, Product.quantity.get(0).intValue()); //Check the quantity
        assertEquals("Toyota", Product.manufacturer.get(0)); //Check the manufacturer
        assertEquals("Camry", Product.model.get(0)); //Check the model
        assertEquals("TestDescription", Product.description.get(0)); //Check the description
        assertEquals("T12345678", Product.code.get(0)); //Check the code
    }
    
    @Test
    public void testSearchPart() {
        //Prepare test input
        product.code.add("T12345678");
        product.brand.add("TestBrand");
        product.price.add(10.99);
        product.quantity.add(5);
        product.manufacturer.add("Toyota");
        product.model.add("Camry");
        product.description.add("TestDescription");
        
        String input = "T12345678\n";
        InputStream in = new ByteArrayInputStream(input.getBytes());
        System.setIn(in);

        //Call the method under test
        product.searchPart();

        //Verify the expected results
        String expectedOutput = "\nPART 1\n" +
                "----------------------------------------\n" +
                "Brand: TestBrand\n" +
                "Price R: 10.99\n" +
                "Quantity of product : 5\n" +
                "Manufacturer: Toyota\n" +
                "Model: Camry\n" +
                "Description: TestDescription\n" +
                "Part Code: T12345678" +
                "----------------------------------------\n";
        
        assertEquals(expectedOutput, outContent.toString());
    }
    
    @Test
    public void testDisplayParts() {
        //Prepare test data
        product.brand.add("Brand1");
        product.price.add(10.99);
        product.quantity.add(5);
        product.manufacturer.add("Manufacturer1");
        product.model.add("Model1");
        product.description.add("Description1");
        product.code.add("Code1");

        product.brand.add("Brand2");
        product.price.add(20.99);
        product.quantity.add(10);
        product.manufacturer.add("Manufacturer2");
        product.model.add("Model2");
        product.description.add("Description2");
        product.code.add("Code2");

        //Call the method under test
        product.displayParts();

        //Verify the expected results
        String expectedOutput = "\nPART 1\n" +
                "----------------------------------------\n" +
                "Brand: Brand1\n" +
                "Price R: 10.99\n" +
                "Quantity of product : 5\n" +
                "Manufacturer: Manufacturer1\n" +
                "Model: Model1\n" +
                "Description: Description1\n" +
                "Part Code: Code1" +
                "----------------------------------------\n" +
                "\nPART 2\n" +
                "----------------------------------------\n" +
                "Brand: Brand2\n" +
                "Price R: 20.99\n" +
                "Quantity of product : 10\n" +
                "Manufacturer: Manufacturer2\n" +
                "Model: Model2\n" +
                "Description: Description2\n" +
                "Part Code: Code2" +
                "----------------------------------------\n";

        assertEquals(expectedOutput, outContent.toString());
    }
}
